import React, { useState, useEffect } from "react";
import { db, collection, getDocs, doc, deleteDoc, updateDoc } from "../../firebase";
import { storage, ref, deleteObject } from "../../firebase";
import NewTestimonial from "./NewTestimonial";

const Testimonial = () => {
  const [openAddNewTestimonial, setOpenAddNewTestimonial] = useState(false);
  const [testimonials, setTestimonials] = useState([]);
  const [editTestimonial, setEditTestimonial] = useState(null);

  const fetchTestimonials = async () => {
    try {
      const querySnapshot = await getDocs(collection(db, "testimonials"));
      const testimonialsList = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setTestimonials(testimonialsList);
    } catch (error) {
      console.error("Error fetching testimonials:", error);
    }
  };

  useEffect(() => {
    fetchTestimonials();
  }, []);

  const handleAddTestimonial = (newTestimonial) => {
    setTestimonials((prevTestimonials) => [...prevTestimonials, newTestimonial]);
  };

  const handleEditTestimonial = (testimonial) => {
    setEditTestimonial(testimonial);
    setOpenAddNewTestimonial(true);
  };

  const handleUpdateTestimonial = async (updatedTestimonial) => {
    try {
      const testimonialDocRef = doc(db, "testimonials", updatedTestimonial.id);
      if (editTestimonial.image && updatedTestimonial.image !== editTestimonial.image) {
        const oldImageRef = ref(storage, editTestimonial.image);
        await deleteObject(oldImageRef);
        console.log("Old image deleted successfully");
      }

      await updateDoc(testimonialDocRef, {
        ...updatedTestimonial,
        image: updatedTestimonial.image || "", 
      });

      fetchTestimonials();
      setOpenAddNewTestimonial(false);
      setEditTestimonial(null);
    } catch (error) {
      console.error("Error updating testimonial:", error);
    }
  };

  const handleDeleteTestimonial = async (testimonial) => {
    try {
      if (window.confirm("Are you sure you want to delete this testimonial?")) {
        if (testimonial.image) {
          console.log("Deleting image at path:", testimonial.image);
          const imageRef = ref(storage, testimonial.image);
          await deleteObject(imageRef)
            .then(() => {
              console.log("Image deleted successfully");
            })
            .catch((error) => {
              console.error("Error deleting image:", error);
            });
        }
        await deleteDoc(doc(db, "testimonials", testimonial.id));
        fetchTestimonials();
      }
    } catch (error) {
      console.error("Error deleting testimonial:", error);
    }
  };

  return (
    <div className="w-screen h-screen bg-white flex">
      <div className="dashboard-content bg-white p-4 relative overflow-x-scroll">
        {openAddNewTestimonial && (
          <NewTestimonial
            onCancel={() => setOpenAddNewTestimonial(false)}
            onAddTestimonial={handleAddTestimonial}
            testimonialToEdit={editTestimonial}
            onUpdateTestimonial={handleUpdateTestimonial}
          />
        )}
        <div className="w-full h-full flex flex-col">
          <div className="w-full h-[4rem] flex justify-end">
            <button
              type="button"
              onClick={() => {
                setEditTestimonial(null);
                setOpenAddNewTestimonial(true);
              }}
              className="w-[8rem] h-full bg-blue-500 rounded-md flex justify-center items-center cursor-pointer text-white"
            >
              <p>Add New Testimonial</p>
            </button>
          </div>
          <div className="w-full h-full overflow-y-scroll flex flex-col gap-4 mt-4">
            {testimonials.map((testimonial) => (
              <div
                key={testimonial.id}
                className="w-full h-fit p-4 bg-slate-100 rounded-md flex gap-4"
              >
                <img
                  src={testimonial.image}
                  alt="Testimonial"
                  className="w-[6rem] h-[6rem] rounded-md object-cover"
                />
                <div className="w-full flex flex-col justify-center">
                  <p className="text-lg font-medium">{testimonial.name}</p>
                  <p className="text-sm text-gray-600">{testimonial.designation}</p>
                  <p className="text-sm text-gray-600">{testimonial.organization}</p>
                  <p className="mt-2">{testimonial.description}</p>
                  <div className="mt-4 flex gap-2">
                    <button
                      type="button"
                      onClick={() => handleEditTestimonial(testimonial)}
                      className="w-[6rem] h-[2rem] bg-blue-500 rounded-md text-white flex items-center justify-center"
                    >
                      Edit
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteTestimonial(testimonial)}
                      className="w-[6rem] h-[2rem] bg-red-500 rounded-md text-white flex items-center justify-center"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Testimonial;
