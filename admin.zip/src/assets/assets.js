import Search from "./search.png";
import edit from "./edit.png";
import Delete from "./delete.png";
import Bg from "./bg.jpeg";
import Knowledge_gray from "./bulb-gray.png";
import Knowledge_white from "./bulb-white.png";
import Calender_gray from "./calendar-gray.png";
import Calender_white from "./calendar-white.png";
import Leader_gray from "./leader-gray.png";
import Leader_white from "./leader-white.png";
import Testimonial_gray from "./testimonials-gray.png";
import Testimonial_white from "./testimonial-white.png";
import Menu_Icon from "./menu.png";
import WowHRLogo from "./WowHRLogo.png";

const Img = {
  Search,
  edit,
  Delete,
  Bg,
  Knowledge_gray,
  Knowledge_white,
  Calender_gray,
  Calender_white,
  Leader_gray,
  Leader_white,
  Testimonial_gray,
  Testimonial_white,
  Menu_Icon,
  WowHRLogo
};

export default { Img };
